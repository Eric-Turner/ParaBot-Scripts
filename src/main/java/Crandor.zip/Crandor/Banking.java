package Crandor;


import org.parabot.environment.api.utils.Time;
import org.parabot.environment.scripts.framework.SleepCondition;
import org.parabot.environment.scripts.framework.Strategy;
import org.rev317.min.api.methods.*;
import org.rev317.min.api.wrappers.Item;
import org.rev317.min.api.wrappers.SceneObject;
import org.rev317.min.api.wrappers.Tile;
import org.rev317.min.api.wrappers.TilePath;


/**
 * Created by Eric on 4/6/2016.
 */
class Banking implements Strategy {

    final int BANK_BOOTH_ID = 2213;
    final int BANK_INTERFACE_ID = 5292;
    final int[] FISHING_TOOL_IDS = {304, 312, 302};


    @Override
    public boolean activate() {
        return Inventory.isFull();
    }

    @Override
    public void execute() {
        for (final SceneObject bank : SceneObjects.getNearest(BANK_BOOTH_ID)) {
            Tile[] tiles = {Players.getMyPlayer().getLocation(), bank.getLocation()};
            final TilePath t = new TilePath(tiles);
            if (bank.distanceTo() <= 5) {
                if (Game.getOpenInterfaceId() != BANK_INTERFACE_ID) {
                        bank.interact(1);
                        Time.sleep(new SleepCondition() {
                            @Override
                            public boolean isValid() {
                                return Game.getOpenInterfaceId() == BANK_INTERFACE_ID;
                            }
                        }, 5000);
                } else {
                    if (Game.getOpenInterfaceId() == BANK_INTERFACE_ID) {
                        if (Inventory.isFull()) {
                            for (Item x : Inventory.getItems()) {
                                if (x != null) {
                                    if (x.getId() != FISHING_TOOL_IDS[0] && x.getId() != FISHING_TOOL_IDS[1] && x.getId() != FISHING_TOOL_IDS[2]) {
                                        Menu.sendAction(78, x.getId() - 1, x.getSlot(), 5064);
                                        Time.sleep(100);
                                    }
                                }
                            }
                        }
                        if (!Inventory.isFull()){
                            if (Game.getOpenInterfaceId() == BANK_INTERFACE_ID){
                                Methods.closeBank();
                            }
                        }
                    }
                }
            } else {
                    t.traverse();
                    Time.sleep(new SleepCondition() {
                        @Override
                        public boolean isValid() {
                            return t.hasReached();
                        }
                    }, 25000);
            }
        }
    }
}
