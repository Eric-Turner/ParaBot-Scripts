package Crandor;

import org.parabot.environment.api.utils.Time;
import org.parabot.environment.scripts.framework.SleepCondition;
import org.rev317.min.api.methods.*;
import org.rev317.min.api.wrappers.*;

/**
 * Created by Eric on 4/29/2016.
 */
public class Fishing implements org.parabot.environment.scripts.framework.Strategy {
    public static boolean net_fishing = false;
    public static boolean harpoon_fishing = false;
    public static boolean cage_fishing = false;

    public static boolean auto_progression = false;



    int fishing_animation_id;

    int fishing_spot_id;


    @Override
    public boolean activate() {
        return !Inventory.isFull();
    }

    @Override
    public void execute() {
        if (auto_progression) {
            if (Methods.isBetween(Skill.FISHING.getLevel(), 1, 34)) {
                //Net Fishing
                fishing_spot_id = 25375;
                for (SceneObject x : SceneObjects.getNearest(fishing_spot_id)) {
                    if (x != null) {
                        x.interact(0);

                    }
                }
            }
            if (Methods.isBetween(Skill.FISHING.getLevel(), 35, 40)) {
                //Harpoon fishing
            }
            if (Methods.isBetween(Skill.FISHING.getLevel(), 40, 99)) {
                //Cage fishing
            }
        } else {

            if (net_fishing) {
                fishing_spot_id = 316;
                fishing_animation_id = 621;

            }
            if (cage_fishing) {
                fishing_spot_id = 312;
                fishing_animation_id = 619;
            }
            if (harpoon_fishing) {
                fishing_spot_id = 312;
                fishing_animation_id = 618;
            }
                for (final Npc x : Npcs.getNearest(fishing_spot_id)) {
                    Tile[] tiles = {Players.getMyPlayer().getLocation(), x.getLocation()};
                    final TilePath t = new TilePath(tiles);
                    if (x.getLocation().distanceTo() <= 3) {
                            if (Players.getMyPlayer().getAnimation() != fishing_animation_id) {
                                if (cage_fishing || net_fishing) {
                                    x.interact(0);
                                    Time.sleep(new SleepCondition() {
                                        @Override
                                        public boolean isValid() {
                                            return Players.getMyPlayer().getAnimation() == fishing_animation_id;
                                        }
                                    }, 5000);
                                }else{
                                    x.interact(2);
                                    Time.sleep(new SleepCondition() {
                                        @Override
                                        public boolean isValid() {
                                            return Players.getMyPlayer().getAnimation() == fishing_animation_id;
                                        }
                                    }, 5000);
                                }
                                Time.sleep(new SleepCondition() {
                                    @Override
                                    public boolean isValid() {
                                        return Players.getMyPlayer().getAnimation() != fishing_animation_id;
                                    }
                                }, 25000);
                            }
                    }
                    if (x.getLocation().distanceTo() > 3){
                        if (Players.getMyPlayer().getAnimation() != fishing_animation_id) {
                            t.traverse();
                            Time.sleep(new SleepCondition() {
                                @Override
                                public boolean isValid() {
                                    return t.hasReached();
                                }
                            }, 25000);
                        }
                    }
                }
        }
    }
}
